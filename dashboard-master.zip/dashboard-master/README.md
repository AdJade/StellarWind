# dashboard

```sh
yarn
```

## Developing

```sh
yarn start
```

If you wish to use backend server API start this command in another terminal
window:

```sh
DEV=true node ./app.js
```

It will create a proxy to `browser-sync` server started by gulp at
`http://localhost:5000`
